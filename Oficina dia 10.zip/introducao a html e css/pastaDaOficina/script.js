user = document.getElementById("user");
password = document.getElementById("password");

